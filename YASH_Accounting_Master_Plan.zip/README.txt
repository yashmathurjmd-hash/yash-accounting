YASH Accounting Master Plan
Stable baseline: V50
Use this plan for future development.